﻿using DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
   public class UserInfoBLL
    {
       UserInfoDAL dal = new UserInfoDAL();

        public IEnumerable<Model.UserInfo> SelectAll()
        {
            return dal.SelectAll();
        }

        public int Remove(int id)
        {
            return dal.Remove(id);
        }
       //新增
        public int Insert(Model.UserInfo model)
        {
            return dal.Insert(model);
        }

        public Model.UserInfo GetUserById(int id)
        {
            return dal.GetUserById(id);
        }

        public bool Update(Model.UserInfo model)
        {
            return dal.Update(model);
        }
    }
}
