﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace DAL
{
   public class SqlHelper
    {
       public static readonly string constr = ConfigurationManager.ConnectionStrings["mssqlserver"].ConnectionString;

       public static int ExecuteNonQuery(string sql,CommandType cmdType,params SqlParameter[] pms) {
           using (SqlConnection conn = new SqlConnection(constr)) {
               using (SqlCommand cmd = conn.CreateCommand()) {
                   conn.Open();
                   cmd.CommandText = sql;
                   cmd.CommandType = cmdType;
                   cmd.Parameters.AddRange(pms);
                   return cmd.ExecuteNonQuery();
               }
           }
       }


       public static Object ExecuteScaler(string sql, CommandType cmdType, params SqlParameter[] pms) {
           using (SqlConnection conn = new SqlConnection(constr)) {
               using (SqlCommand cmd = conn.CreateCommand()) {
                   conn.Open();
                   cmd.CommandText = sql;
                   cmd.CommandType = cmdType;
                   cmd.Parameters.AddRange(pms);
                   return cmd.ExecuteScalar();

               }
           }
       }


       public static SqlDataReader ExecuteReader(string sql, CommandType cmdType, params SqlParameter[] pms) {
           SqlConnection conn = new SqlConnection(constr);
           try{
               using(SqlCommand cmd = conn.CreateCommand()){
                   cmd.CommandText = sql;
                   cmd.CommandType = cmdType;
                   cmd.Parameters.AddRange(pms);
                   conn.Open();
                   return cmd.ExecuteReader(CommandBehavior.CloseConnection);
               }
           }catch{
               conn.Close();
               conn.Dispose();
               throw;
           }
       }

     // 将一个SqlDataReader对象转换成一个实体类对象 
     
       public static TEntity MapEntity<TEntity>(SqlDataReader reader) where TEntity : class,new()
       {
           try
           {

               TEntity entity = new TEntity();
               var props = typeof(TEntity).GetProperties(); //获取所有公共属性
               foreach (var item in props)
               {
                   //是否可写
                   if (item.CanWrite) {
                       try
                       {
                           var index = reader.GetOrdinal(item.Name); //获取列名序号
                           var data = reader.GetValue(index);
                           if (data != DBNull.Value) {
                               //用索引属性的可选索引值设置指定对象的属性值
                               item.SetValue(entity, Convert.ChangeType(data, item.PropertyType));
                           }
                       }
                       catch (IndexOutOfRangeException){
                           continue;
                       }
                   }
               }
               return entity;
           }
           catch 
           {

               return null;
           }
       }

    }
}
