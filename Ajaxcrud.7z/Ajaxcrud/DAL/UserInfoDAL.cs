﻿using Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class UserInfoDAL
    {
        public IEnumerable<UserInfo> SelectAll()
        {
            string sql = "select * from UserInfo";
           // List<UserInfo> list = new List<UserInfo>();
            using (SqlDataReader reader = SqlHelper.ExecuteReader(sql, CommandType.Text))
            {
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        //UserInfo model = new UserInfo();
                        //model.ID = reader.GetInt32(0);
                        //model.UserName = reader.GetString(1);
                        //model.UserPwd = reader.GetString(2);
                        //model.UserEmail = reader.GetString(3);
                        //list.Add(model);
                        yield return SqlHelper.MapEntity<UserInfo>(reader);
                    }
                }
            }
          //  return list;
        }
        //删除
        public int Remove(int id)
        {
            string sql = "delete from UserInfo where ID=@id";
            SqlParameter pm = new SqlParameter("@id", SqlDbType.Int) { Value = id };
            return SqlHelper.ExecuteNonQuery(sql, CommandType.Text, pm);
        }
        //新增
        public int Insert(UserInfo model)
        {
            string sql = "insert into UserInfo  values(@name,@pwd,@email)";
            SqlParameter[] pms = new SqlParameter[]{
                new SqlParameter("@name",SqlDbType.NVarChar,50){Value=model.UserName},
                new SqlParameter("@pwd",SqlDbType.NVarChar,50){Value=model.UserPwd},
                new SqlParameter("@email",SqlDbType.NVarChar,50){Value=model.UserEmail},
            };
            return SqlHelper.ExecuteNonQuery(sql,CommandType.Text,pms);
        }
        //根据id返回
        public UserInfo GetUserById(int id)
        {
            string sql = "select * from UserInfo  where ID=@id";
            SqlParameter pm = new SqlParameter("@id", SqlDbType.Int) { Value = id };
            UserInfo model = new UserInfo();
            using (SqlDataReader reader = SqlHelper.ExecuteReader(sql, CommandType.Text, pm)) {
                if (reader.HasRows) {
                    if (reader.Read())
                    {
                        //model.ID = reader.GetInt32(0);
                        //model.UserName = reader.GetString(1);
                        //model.UserPwd = reader.GetString(2);
                        //model.UserEmail = reader.GetString(3);
                        model= SqlHelper.MapEntity<UserInfo>(reader);
                    }
                }
            }
           return model;
        }
        //修改
        public bool Update(UserInfo model)
        {
            string sql = "update UserInfo set UserName=@name,UserEmail=@email where ID=@id";
            SqlParameter[] pms = new SqlParameter[] { 
                new SqlParameter("@name",SqlDbType.NVarChar,50){Value=model.UserName},
                new SqlParameter("@email",SqlDbType.VarChar,50){Value=model.UserEmail},
                new SqlParameter("@id",SqlDbType.Int){Value=model.ID}
            };
            return SqlHelper.ExecuteNonQuery(sql,CommandType.Text,pms)>0;
        }
    }
}
