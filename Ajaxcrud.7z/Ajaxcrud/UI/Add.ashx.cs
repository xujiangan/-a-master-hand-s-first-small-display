﻿using BLL;
using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Utility;

namespace UI
{
    /// <summary>
    /// Add 的摘要说明
    /// </summary>
    public class Add : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
            UserInfoBLL bll = new UserInfoBLL();
            context.Response.ContentType = "text/plain";
            string name=context.Request["userName"];
            string pwd = context.Request["userPwd"];
            string email=context.Request["userEmail"];

            if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(pwd) || string.IsNullOrEmpty(email))
            {
                return;
            }
            else {
                UserInfo model = new UserInfo()
                {
                    UserName = name,
                    UserPwd = CommonHelper.GetStringMD5(pwd),
                    UserEmail = email
                };
                if (bll.Insert(model) > 0) {
                    context.Response.Write("ok");
                }
            }
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}