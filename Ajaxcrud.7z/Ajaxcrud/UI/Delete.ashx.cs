﻿using BLL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UI
{
    /// <summary>
    /// Delete 的摘要说明
    /// </summary>
    public class Delete : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/plain";
            UserInfoBLL bll = new UserInfoBLL();

            int id = Convert.ToInt32(context.Request.QueryString["id"]);
            string result="";
            if (id > 0)
            {
                if (bll.Remove(id) > 0)
                {
                    result = "1";
                }
                else {
                    result = "0";
                }
            }
            else {
                result = "-1";
            }
            context.Response.Write(result);
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}