﻿using BLL;
using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;

namespace UI
{
    /// <summary>
    /// Edit 的摘要说明
    /// </summary>
    public class Edit : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
            UserInfoBLL bll = new UserInfoBLL(); 
            context.Response.ContentType = "text/plain";
            string nn = context.Request["uname"];
            if (context.Request["uid"] == null)
            {
                int id = Convert.ToInt32(context.Request["id"]);
                if (id > 0)
                {
                    UserInfo model = bll.GetUserById(id);
                    if (model != null)
                    {
                        JavaScriptSerializer jss = new JavaScriptSerializer();
                        context.Response.Write(jss.Serialize(model));
                    }

                }
            }
            else { 
                //用户修改回发过来的
                UserInfo model = new UserInfo();
                model.ID = Convert.ToInt32(context.Request["uid"]);
                model.UserName = context.Request["uname"];
                model.UserEmail=context.Request["uemail"];
                if (bll.Update(model))
                {
                    context.Response.Write("ok");
                }
                else {
                    context.Response.Write("no");
                }
            }
           
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}