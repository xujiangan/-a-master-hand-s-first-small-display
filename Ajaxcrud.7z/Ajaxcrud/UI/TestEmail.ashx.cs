﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Utility;

namespace UI
{
    /// <summary>
    /// TestEmail 的摘要说明
    /// </summary>
    public class TestEmail : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/plain";
            string toEmail = context.Request["txtEamil"];
            string title=context.Request["txtTitle"];
            string content=context.Request["txtContent"];
            if (MailHelper.Send(toEmail, title, content))
            {
                context.Response.Write("ok");
            }
            else {
                context.Response.Write("no");
            }

        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}