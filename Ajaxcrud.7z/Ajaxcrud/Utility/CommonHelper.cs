﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Utility
{
    public class CommonHelper
    {
        public static string GetStringMD5(string pwd)
        {
            StringBuilder sb = new StringBuilder();
            byte[] bytes = System.Text.Encoding.UTF8.GetBytes(pwd);
            using(MD5 md5=MD5.Create()){
                byte[] temp = md5.ComputeHash(bytes);
                for (int i = 0; i < temp.Length; i++)
                {
                    sb.Append(temp[i].ToString("x2"));
                }
            }
            return sb.ToString();
        }
    }
}
