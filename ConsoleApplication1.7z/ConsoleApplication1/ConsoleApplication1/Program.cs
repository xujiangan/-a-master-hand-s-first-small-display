﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using NPOI.HSSF.UserModel;
using NPOI.SS.UserModel;
using NPOI.OpenXmlFormats;
namespace ConsoleApplication1
{
    class Program
    {
        /// <summary>
        /// 导出
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            ////以文件流的形式读取表格或者读取数据库
            //using (FileStream fs = new FileStream("1.xls", FileMode.Open))
            //{
            //    //创建一个sheet
            //    IWorkbook work = WorkbookFactory.Create(fs);
            //    //获取sheet中的第一个表(不包含表的第一行)
            //    ISheet sheet = work.GetSheetAt(0);
            //    //循环遍历表中的每一行
            //    for (int i = 0; i <= sheet.LastRowNum; i++)
            //    {
            //        //获取所有行数
            //        IRow row = sheet.GetRow(i);
            //        //遍历表的列数
            //        for (int j = 0; j < row.LastCellNum; j++)
            //        {
            //            //获取所有的列数
            //            ICell cell = row.GetCell(j);
            //            //判断每一个单元格的数据类型(字符串)
            //            if (cell.CellType == CellType.STRING || cell.CellType == CellType.NUMERIC)
            //            {
            //                string str = string.Empty;
            //                string s = str += cell.StringCellValue;
            //                //输出单元格的值
            //                Console.WriteLine(cell.StringCellValue);
            //            }
            //        }
            //    }
            //}
            ////导出(从数据库读取数据然后填充)    HSSF导出格式是office2003(兼容  wps可以打开)
            IWorkbook work = new HSSFWorkbook();
            //创建sheet
            ISheet sheet = work.CreateSheet("掌何天下");
            //创建sheet表的第一行（标题）
            IRow row = sheet.CreateRow(0);
            //创建单元格
            ICell cell = row.CreateCell(0, CellType.STRING);
            //填充数据
            cell.SetCellValue("业务");
            //创建第二个单元格
            cell = row.CreateCell(1, CellType.STRING);
            cell.SetCellValue("地址");
            //第二行
            IRow rows = sheet.CreateRow(1);
            ICell cells = rows.CreateCell(0, CellType.STRING);
            cells.SetCellValue("超市系统");
            cells = rows.CreateCell(1, CellType.STRING);
            cells.SetCellValue("银河SOHO");
            //写入文件
            using (FileStream fs = new FileStream("123.xls", FileMode.OpenOrCreate))
            {
                work.Write(fs);
            }
            Console.WriteLine("OK");
            Console.ReadKey();
        }
    }
}
