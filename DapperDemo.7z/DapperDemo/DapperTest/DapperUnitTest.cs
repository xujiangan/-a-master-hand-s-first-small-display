﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using Newtonsoft.Json;
using SqlMapper;
using System.Data;
using System.Globalization;
using System.Linq;
using Dapper;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using MySql.Data.MySqlClient;

namespace DapperTest
{

    [TestClass]
    public class DapperShareUnitTest
    {
        SqlConnection connection = new SqlConnection(ConfigurationManager.AppSettings["ConnectionString"]);
        //MySqlConnection connection = new SqlConnection(ConfigurationManager.AppSettings["ConnectionString"]);

        #region No0 ☆
        [TestMethod]
        public void TestMapWithConstructor()
        {

           connection.Execute("drop table #Users");
            var createSql = @"-- create table Users (Id int, Name varchar(20));
                                insert Users values(99, 'Sam');
                                insert Users values(2, 'I am')";
            connection.Execute(createSql);
            string sql = @"select * from  Users u";
            List<User> users = connection.Query<User>(sql).ToList();

            Console.WriteLine(users.Count);
        }
        #endregion

        #region No1
        #region Models
        public class AbstractInheritance
        {
            public abstract class Order
            {
                internal int Internal { get; set; }
                protected int Protected { get; set; }
                public int Public { get; set; }

                public int ProtectedVal { get { return Protected; } }
            }

            public class ConcreteOrder : Order
            {
                public int Concrete { get; set; }
            }
        }

        class UserWithConstructor
        {
            public UserWithConstructor(int id, string name)
            {
                Ident = id;
                FullName = name;
            }
            public int Ident { get; set; }
            public string FullName { get; set; }
        }

        class PostWithConstructor
        {
            public PostWithConstructor(int id, int ownerId, string content)
            {
                Ident = id;
                FullContent = content;
            }

            public int Ident { get; set; }
            public UserWithConstructor Owner { get; set; }
            public string FullContent { get; set; }
            public Comment Comment { get; set; }
        }

        class Comment
        {
            public int Id { get; set; }
            public string CommentData { get; set; }
        }
        #endregion
        [TestMethod]
        public void TestMultiMapWithConstructor()
        {
            var createSql = @"
                create table Users (Id int, Name varchar(20))
                create table Posts (Id int, OwnerId int, Content varchar(20))

                insert Users values(99, 'Sam')
                insert Users values(2, 'I am')

                insert Posts values(1, 99, 'Sams Post1')
                insert Posts values(2, 99, 'Sams Post2')
                insert Posts values(3, null, 'no ones post')
                insert Posts values(4, 2, 'I am Post')";
            //  connection.Execute(createSql);
            string sql = @"select * from  Users u 
                           right join Posts p on u.Id = p.OwnerId 
                           Order by p.Id";
            PostWithConstructor[] data = connection.Query<UserWithConstructor, PostWithConstructor, PostWithConstructor>(sql, (user, post) => { post.Owner = user; return post; }).ToArray();

            foreach (PostWithConstructor postWithConstructor in data)
            {
                try
                {
                    Console.WriteLine("Ident:{0}", postWithConstructor.Ident);
                    Console.WriteLine("FullContent:{0}", postWithConstructor.FullContent);
                    Console.WriteLine("Owner.Ident:{0}", postWithConstructor.Owner.Ident);
                    Console.WriteLine("Owner.FullName:{0}", postWithConstructor.Owner.FullName);
                }
                catch (Exception exception)
                {
                    Console.WriteLine(exception.Message);
                }
                Console.WriteLine();
            }
        }
        #endregion

//        #region No2.1
//        class MultipleConstructors
//        {
//            public MultipleConstructors()
//            {
//
//            }
//
//            public MultipleConstructors(int a, string b, string c)
//            {
//                A = a + 1;
//                B = b + "!";
//            }
//
//            [ExplicitConstructor]
//            public MultipleConstructors(int a, string b)
//            {
//                A = a + 1;
//                B = b + "!";
//            }
//
//            public int A { get; set; }
//            public string B { get; set; }
//        }
//
//        [TestMethod]
//        public void TestMultipleConstructors()
//        {
//            MultipleConstructors mult = connection.Query<MultipleConstructors>("select 0 A, 'Dapper' B").First();
//
//            Console.WriteLine(mult.A);
//            Console.WriteLine(mult.B);
//        }
//        #endregion
//
//        #region No2.2
//        class ConstructorsWithAccessModifiers
//        {
//            private ConstructorsWithAccessModifiers()
//            {
//            }
//            public ConstructorsWithAccessModifiers(int a, string b)
//            {
//                A = a + 1;
//                B = b + "!";
//            }
//            public int A { get; set; }
//            public string B { get; set; }
//        }
//
//        [TestMethod]
//        public void TestConstructorsWithAccessModifiers()
//        {
//            ConstructorsWithAccessModifiers value = connection.Query<ConstructorsWithAccessModifiers>("select 0 A, 'Dapper' b").First();
//            value.A.IsEqualTo(1);
//            value.B.IsEqualTo("Dapper!");
//            Console.WriteLine(value.A);
//            Console.WriteLine(value.B);
//        }
//
//        #endregion
//
//        #region No2.3
//        class NoDefaultConstructor
//        {
//            public NoDefaultConstructor(int a1, int? b1, float f1, string s1, Guid G1)
//            {
//                A = a1;
//                B = b1;
//                F = f1;
//                S = s1;
//                G = G1;
//            }
//            public int A { get; set; }
//            public int? B { get; set; }
//            public float F { get; set; }
//            public string S { get; set; }
//            public Guid G { get; set; }
//        }
//
//        [TestMethod]
//        public void TestNoDefaultConstructor()
//        {
//            var guid = Guid.NewGuid();
//            NoDefaultConstructor nodef = connection.Query<NoDefaultConstructor>("select CAST(NULL AS integer) A1,  CAST(NULL AS integer) b1, CAST(NULL AS real) f1, 'Dapper' s1, G1 = @id", new { id = guid }).First();
//
//            nodef.A.IsEqualTo(0);
//            nodef.B.IsEqualTo(null);
//            nodef.F.IsEqualTo(0);
//            nodef.S.IsEqualTo("Dapper");
//            nodef.G.IsEqualTo(guid);
//
//            Console.WriteLine(nodef.A);
//            Console.WriteLine(nodef.B);
//            Console.WriteLine(nodef.F);
//            Console.WriteLine(nodef.S);
//            Console.WriteLine(nodef.G);
//        }
//
//        #endregion
//
//        #region No2.4
//        class NoDefaultConstructorWithChar
//        {
//            public NoDefaultConstructorWithChar(char c1, char? c2, char? c3)
//            {
//                Char1 = c1;
//                Char2 = c2;
//                Char3 = c3;
//            }
//            public char Char1 { get; set; }
//            public char? Char2 { get; set; }
//            public char? Char3 { get; set; }
//        }
//        [TestMethod]
//        public void TestNoDefaultConstructorWithChar()
//        {
//            const char c1 = 'ą';
//            const char c3 = 'ó';
//            NoDefaultConstructorWithChar nodef = connection.Query<NoDefaultConstructorWithChar>("select @c1 c1, @c2 c2, @c3 c3", new { c1 = c1, c2 = (char?)null, c3 = c3 }).First();
//            nodef.Char1.IsEqualTo(c1);
//            Console.WriteLine(nodef.Char1);
//            nodef.Char2.IsEqualTo(null);
//            Console.WriteLine(nodef.Char2);
//            nodef.Char3.IsEqualTo(c3);
//            Console.WriteLine(nodef.Char3);
//        }
//
//        #endregion
//
//        #region No2.4
//        public enum ShortEnum : short
//        {
//            Zero = 0, One = 1, Two = 2, Three = 3, Four = 4, Five = 5, Six = 6
//        }
//        class NoDefaultConstructorWithEnum
//        {
//            public NoDefaultConstructorWithEnum(ShortEnum e1, ShortEnum? n1, ShortEnum? n2)
//            {
//                E = e1;
//                NE1 = n1;
//                NE2 = n2;
//            }
//            public ShortEnum E { get; set; }
//            public ShortEnum? NE1 { get; set; }
//            public ShortEnum? NE2 { get; set; }
//        }
//        [TestMethod]
//        public void TestNoDefaultConstructorWithEnum()
//        {
//            NoDefaultConstructorWithEnum nodef = connection.Query<NoDefaultConstructorWithEnum>("select cast(2 as smallint) E1, cast(5 as smallint) n1, cast(null as smallint) n2").First();
//            nodef.E.IsEqualTo(ShortEnum.Two);
//            Console.WriteLine("nodef.E:{0}", nodef.E);
//            nodef.NE1.IsEqualTo(ShortEnum.Five);
//            Console.WriteLine("nodef.NE1:{0}", nodef.NE1);
//            nodef.NE2.IsEqualTo(null);
//            Console.WriteLine("nodef.NE2:{0}", nodef.NE2);
//        }
//        #endregion
//
//        #region No2.5
//
//        class NoDefaultConstructorWithBinary
//        {
//            public System.Data.Linq.Binary Value { get; set; }
//            public int Ynt { get; set; }
//            public NoDefaultConstructorWithBinary(System.Data.Linq.Binary val)
//            {
//                Value = val;
//            }
//        }
//
//        [TestMethod]
//        public void TestNoDefaultConstructorBinary()
//        {
//            byte[] orig = new byte[20];
//            new Random(123456).NextBytes(orig);
//            var input = new System.Data.Linq.Binary(orig);
//            var output = connection.Query<NoDefaultConstructorWithBinary>("select @input as val", new { input }).First().Value;
//            output.ToArray().IsSequenceEqualTo(orig);
//            Console.WriteLine("output:{0}", output);
//            Console.WriteLine("input:{0}", input);
//            Console.WriteLine("output.GetType():{0}", output.GetType());
//            Console.WriteLine("input.GetType():{0}", input.GetType());
//        }
//        #endregion

        #region No3
        [TestMethod]
        public void TestAbstractInheritance()
        {
            var order = connection.Query<AbstractInheritance.ConcreteOrder>("select 1 Internal,2 Protected,3 [Public],4 Concrete").First();

            order.Internal.IsEqualTo(1);
            Console.WriteLine("order.Internal:{0}", order.Internal);
            order.ProtectedVal.IsEqualTo(2);
            Console.WriteLine("order.ProtectedVal:{0}", order.ProtectedVal);
            order.Public.IsEqualTo(3);
            Console.WriteLine("order.Public:{0}", order.Public);
            order.Concrete.IsEqualTo(4);
            Console.WriteLine("order.Concrete:{0}", order.Concrete);
        }

        #endregion

        #region No4
        [TestMethod]
        public void TestListOfAnsiStrings()
        {
            var results = connection.Query<string>("select * from (select 'a' str union select 'b' union select 'c') X where str in @strings",
                new { strings = new[] { new DbString { IsAnsi = true, Value = "a" }, new DbString { Value = "b" } } }).ToList();

            results[0].IsEqualTo("a");
            Console.WriteLine("results[0]:{0}", results[0]);
            results[1].IsEqualTo("b");
            Console.WriteLine("results[1]:{0}", results[1]);
            Console.WriteLine(JsonConvert.SerializeObject(results));
        }

        #endregion

        #region No5
        [TestMethod]
        public void TestNullableGuidSupport()
        {
            var guid = connection.Query<Guid?>("select null").First();
            guid.IsNull();
            Console.WriteLine("guid:{0}", guid);

            guid = Guid.NewGuid();
            var guid2 = connection.Query<Guid?>("select @guid", new { guid }).First();
            //guid.IsEqualTo(guid2);
            Console.WriteLine("guid2:{0}", guid2);
        }
        #endregion

        #region No6
        [TestMethod]
        public void TestNonNullableGuidSupport()
        {
            var guid = Guid.NewGuid();
            var guid2 = connection.Query<Guid?>("select @guid", new { guid }).First();
            Console.WriteLine("guid:{0}", guid);
            Console.WriteLine("guid2:{0}", guid2);
            Console.WriteLine("guid==guid2:{0}", guid == guid2);
        }
        #endregion

        #region No7
        struct Car
        {
            public enum TrapEnum : int
            {
                A = 1,
                B = 2
            }
#pragma warning disable 0649
            public string Name;
#pragma warning restore 0649
            public int Age { get; set; }
            public TrapEnum Trap { get; set; }

        }

        struct CarWithAllProps
        {
            public string Name { get; set; }
            public int Age { get; set; }

            public Car.TrapEnum Trap { get; set; }
        }
        [TestMethod]
        public void TestStructs()
        {
            var car = connection.Query<Car>("select 'Ford' Name, 21 Age, 2 Trap").First();
            Console.WriteLine("car:{0}", JsonConvert.SerializeObject(car));
        }
        #endregion

        #region No8
        [TestMethod]
        public void TestStructAsParam()
        {
            var car1 = new CarWithAllProps { Name = "Ford", Age = 21, Trap = Car.TrapEnum.B };
            // note Car has Name as a field; parameters only respect properties at the moment
            var car2 = connection.Query<CarWithAllProps>("select @Name Name, @Age Age, @Trap Trap", car1).First();

            //car2.Name.IsEqualTo(car1.Name);
            //car2.Age.IsEqualTo(car1.Age);
            //car2.Trap.IsEqualTo(car1.Trap);
            Console.WriteLine("car2.Trap:{0}", car2.Trap);
            Console.WriteLine("car1.Trap:{0}", JsonConvert.SerializeObject(car1.Trap));
            Console.WriteLine("car2:{0}", JsonConvert.SerializeObject(car2));
        }
        #endregion

        #region No9
        [TestMethod]
        public void SelectListInt()
        {
            var result = connection.Query<int>("select 1 union all select 2 union all select 3");
            //               .IsSequenceEqualTo(new[] { 1, 2, 3 });
            Console.WriteLine("result:{0}", JsonConvert.SerializeObject(result));
        }
        #endregion

        #region No10
        [TestMethod]
        public void SelectBinary()
        {
            var result = connection.Query<byte[]>("select cast(1 as varbinary(4))");
            //.First().SequenceEqual(new byte[] { 1 });
            Console.WriteLine("result:{0}", JsonConvert.SerializeObject(result));
        }
        #endregion

        #region No11
        [TestMethod]
        public void PassInIntArray()
        {
            connection.Query<int>("select * from (select 1 as Id union all select 2 union all select 3) as X where Id in @Ids", new { Ids = new int[] { 1, 2, 3 }.AsEnumerable() })
             .IsSequenceEqualTo(new[] { 1, 2, 3 });
        }

        #endregion

        #region No12
        [TestMethod]
        public void PassInEmptyIntArray()
        {
            var result =
                connection.Query<int>(
                    "select * from (select 1 as Id union all select 2 union all select 3) as X where Id in @Ids",
                    new { Ids = new int[0] });
            Console.WriteLine("result:{0}", JsonConvert.SerializeObject(result));
            //.IsSequenceEqualTo(new int[0]);
        }
        #endregion

        #region No13
        public class Dog
        {
            public int? Age { get; set; }
            public Guid Id { get; set; }
            public string Name { get; set; }
            public float? Weight { get; set; }

            public int IgnoredProperty { get { return 1; } }
        }

        [TestMethod]
        public void TestSchemaChangedMultiMap()
        {
            connection.Execute("create table dog(Age int, Name nvarchar(max)) insert dog values(1, 'Alf')");
            try
            {
                var tuple = connection.Query<Dog, Dog, Tuple<Dog, Dog>>("select * from dog d1 join dog d2 on 1=1", (d1, d2) => Tuple.Create(d1, d2), splitOn: "Age").Single();

                tuple.Item1.Name.IsEqualTo("Alf");
                tuple.Item1.Age.IsEqualTo(1);
                tuple.Item2.Name.IsEqualTo("Alf");
                tuple.Item2.Age.IsEqualTo(1);
                Console.WriteLine("tuple:{0}", JsonConvert.SerializeObject(tuple));

                connection.Execute("alter table dog drop column Name");
                tuple = connection.Query<Dog, Dog, Tuple<Dog, Dog>>("select * from dog d1 join dog d2 on 1=1", (d1, d2) => Tuple.Create(d1, d2), splitOn: "Age").Single();
                tuple.Item1.Name.IsNull();
                tuple.Item1.Age.IsEqualTo(1);
                tuple.Item2.Name.IsNull();
                tuple.Item2.Age.IsEqualTo(1);
                Console.WriteLine("tuple:{0}", JsonConvert.SerializeObject(tuple));
                var tuples = connection.Query<Dog, Dog, Tuple<Dog, Dog>>("select * from dog d1 join dog d2 on 1=1",(d1,d2)=>Tuple.Create(d1,d2),splitOn:"Name").FirstOrDefault();//splitOn 分割列，区别是哪个对象
            }
            finally
            {
                connection.Execute("drop table dog");
            }
        }
        #endregion

        #region No14
        [TestMethod]
        public void TestReadMultipleIntegersWithSplitOnAny()
        {
            connection.Query<int, int, int, Tuple<int, int, int>>(
                "select 1,2,3 union all select 4,5,6", Tuple.Create, splitOn: "*")
             .IsSequenceEqualTo(new[] { Tuple.Create(1, 2, 3), Tuple.Create(4, 5, 6) });

            var result = connection.Query<int, int, int, Tuple<int, int, int>>(
                  "select 1,2,3 union all select 4,5,6", Tuple.Create, splitOn: "*");

        }
        #endregion

        #region No15
        public void TestDoubleParam()
        {
            connection.Query<double>("select @d", new { d = 0.1d }).First()
                .IsEqualTo(0.1d);
        }

        public void TestBoolParam()
        {
            connection.Query<bool>("select @b", new { b = false }).First()
                .IsFalse();
        }

        public void TestTimeSpanParam()
        {
            connection.Query<TimeSpan>("select @ts", new { ts = TimeSpan.FromMinutes(42) }).First()
                .IsEqualTo(TimeSpan.FromMinutes(42));
        }


        public void TestStrings()
        {
            connection.Query<string>(@"select 'a' a union select 'b'")
                .IsSequenceEqualTo(new[] { "a", "b" });
        }
        #endregion

        #region No16
        // see http://stackoverflow.com/questions/16726709/string-format-with-sql-wildcard-causing-dapper-query-to-break
        public void CheckComplexConcat()
        {
            string end_wildcard = @"
SELECT * FROM #users16726709
WHERE (first_name LIKE CONCAT(@search_term, '%') OR last_name LIKE CONCAT(@search_term, '%'));";

            string both_wildcards = @"
SELECT * FROM #users16726709
WHERE (first_name LIKE CONCAT('%', @search_term, '%') OR last_name LIKE CONCAT('%', @search_term, '%'));";

            string formatted = @"
SELECT * FROM #users16726709
WHERE (first_name LIKE {0} OR last_name LIKE {0});";

            //TODO:@"CONCAT('%', @search_term, '%')";
            string use_end_only = @"CONCAT(@search_term, '%')";
            string use_both = @"CONCAT('%', @search_term, '%')";

            // if true, slower query due to not being able to use indices, but will allow searching inside strings 
            bool allow_start_wildcards = false;

            string query = String.Format(formatted, allow_start_wildcards ? use_both : use_end_only);
            string term = "F"; // the term the user searched for

            connection.Execute(@"create table #users16726709 (first_name varchar(200), last_name varchar(200))
insert #users16726709 values ('Fred','Bloggs') insert #users16726709 values ('Tony','Farcus') insert #users16726709 values ('Albert','TenoF')");

            // Using Dapper
            connection.Query(end_wildcard, new { search_term = term }).Count().IsEqualTo(2);
            connection.Query(both_wildcards, new { search_term = term }).Count().IsEqualTo(3);
            connection.Query(query, new { search_term = term }).Count().IsEqualTo(2);

        }
        #endregion

        #region No17
        enum EnumParam : short
        {
            None, A, B
        }
        class EnumParamObject
        {
            public EnumParam A { get; set; }
            public EnumParam? B { get; set; }
            public EnumParam? C { get; set; }
        }
        class EnumParamObjectNonNullable
        {
            public EnumParam A { get; set; }
            public EnumParam? B { get; set; }
            public EnumParam? C { get; set; }
        }
        public void TestEnumParamsWithNullable()
        {
            EnumParam a = EnumParam.A;
            EnumParam? b = EnumParam.B, c = null;
            var obj = connection.Query<EnumParamObject>("select @a as A, @b as B, @c as C",
                new { a, b, c }).Single();
            obj.A.IsEqualTo(EnumParam.A);
            obj.B.IsEqualTo(EnumParam.B);
            obj.C.IsEqualTo(null);
        }
        [TestMethod]
        public void TestEnumParamsWithoutNullable()
        {
            EnumParam a = EnumParam.A;
            EnumParam b = EnumParam.B, c = 0;
            var obj = connection.Query<EnumParamObjectNonNullable>("select @a as A, @b as B, @c as C",
                new { a, b, c }).Single();
            obj.A.IsEqualTo(EnumParam.A);
            obj.B.IsEqualTo(EnumParam.B);
            obj.C.IsEqualTo((EnumParam)0);//None
            Console.WriteLine(obj.C);
        }
        #endregion

        #region No18

        public void TestExtraFields()
        {
            var guid = Guid.NewGuid();
            var dog = connection.Query<Dog>("select '' as Extra, 1 as Age, 0.1 as Name1 , Id = @id", new { id = guid });

            dog.Count()
               .IsEqualTo(1);

            dog.First().Age
                .IsEqualTo(1);

            dog.First().Id
                .IsEqualTo(guid);
        }
        #endregion

        #region No19
        public void TestStrongType()
        {
            var guid = Guid.NewGuid();
            var dog = connection.Query<Dog>("select Age = @Age, Id = @Id", new { Age = (int?)null, Id = guid });

            dog.Count()
                .IsEqualTo(1);

            dog.First().Age
                .IsNull();

            dog.First().Id
                .IsEqualTo(guid);
        }

        public void TestSimpleNull()
        {
            connection.Query<DateTime?>("select null").First().IsNull();
        }
        #endregion

        #region No20
        /// <summary>
        /// 返回动态行DapperRow
        /// dynamic
        /// </summary>
        [TestMethod]
        public void TestExpando()
        {
            var rows = connection.Query("select 1 A, 2 B union all select 3, 4").ToList();
            ((int)rows[0].A)
                .IsEqualTo(1);

            ((int)rows[0].B)
                .IsEqualTo(2);

            ((int)rows[1].A)
                .IsEqualTo(3);

            ((int)rows[1].B)
                .IsEqualTo(4);
        }

        #endregion

        #region No21
        public void TestStringList()
        {
            connection.Query<string>("select * from (select 'a' as x union all select 'b' union all select 'c') as T where x in @strings", new { strings = new[] { "a", "b", "c" } })
                .IsSequenceEqualTo(new[] { "a", "b", "c" });

            connection.Query<string>("select * from (select 'a' as x union all select 'b' union all select 'c') as T where x in @strings", new { strings = new string[0] })
                   .IsSequenceEqualTo(new string[0]);
        }
        #endregion

        #region No22
        public void TestExecuteCommand()
        {
            connection.Execute(@"
                                set nocount on 
                                create table #t(i int) 
                                set nocount off 
                                insert #t 
                                select @a a union all select @b 
                                set nocount on 
                                drop table #t", new { a = 1, b = 2 }).IsEqualTo(2);
        }
        #endregion

        #region No23
        //TODO:
        [TestMethod]
        public void TestExecuteCommandWithHybridParameters()
        {
            var p = new DynamicParameters(new { a = 1, b = 2 });
            p.Add("c", dbType: DbType.Int32, direction: ParameterDirection.Output);
            connection.Execute(@"set @c = @a + @b", p);
            p.Get<int>("@c").IsEqualTo(3);

            Console.WriteLine(p.Get<int>("@a"));
        }
        #endregion

        #region No24
        public void TestExecuteMultipleCommand()
        {
            connection.Execute("create table #t(i int)");
            try
            {
                int tally = connection.Execute(@"insert #t (i) values(@a)", new[] { new { a = 1 }, new { a = 2 }, new { a = 3 }, new { a = 4 } });
                int sum = connection.Query<int>("select sum(i) from #t").First();
                tally.IsEqualTo(4);
                sum.IsEqualTo(10);
            }
            finally
            {
                connection.Execute("drop table #t");
            }
        }

        class Student
        {
            public string Name { get; set; }
            public int Age { get; set; }
        }

        public void TestExecuteMultipleCommandStrongType()
        {
            connection.Execute("create table #t(Name nvarchar(max), Age int)");
            try
            {
                int tally = connection.Execute(@"insert #t (Name,Age) values(@Name, @Age)", new List<Student>
            {
                new Student{Age = 1, Name = "sam"},
                new Student{Age = 2, Name = "bob"}
            });
                int sum = connection.Query<int>("select sum(Age) from #t").First();
                tally.IsEqualTo(2);
                sum.IsEqualTo(3);
            }
            finally
            {
                connection.Execute("drop table #t");
            }
        }

        public void TestExecuteMultipleCommandObjectArray()
        {
            connection.Execute("create table #t(i int)");
            int tally = connection.Execute(@"insert #t (i) values(@a)", new object[] { new { a = 1 }, new { a = 2 }, new { a = 3 }, new { a = 4 } });
            int sum = connection.Query<int>("select sum(i) from #t drop table #t").First();
            tally.IsEqualTo(4);
            sum.IsEqualTo(10);
        }
        [TestMethod]
        public void TestMassiveStrings()
        {
            var str = new string('X', 20000);
            connection.Query<string>("select @a", new { a = str }).First()
                .IsEqualTo(str);

            Console.WriteLine(str);
        }
        #endregion

        #region No25
        class TestObj
        {
            public int _internal;
            internal int Internal { set { _internal = value; } }

            public int _priv;
            private int Priv { set { _priv = value; } }

            private int PrivGet { get { return _priv; } }
        }

        public void TestSetInternal()
        {
            connection.Query<TestObj>("select 10 as [Internal]").First()._internal.IsEqualTo(10);
        }

        public void TestSetPrivate()
        {
            connection.Query<TestObj>("select 10 as [Priv]").First()._priv.IsEqualTo(10);
        }
        #endregion

        #region No26
        [TestMethod]
        public void TestExpandWithNullableFields()
        {
            var row = connection.Query("select null A, 2 B").Single();
            ((int?)row.A)
                .IsNull();

            ((int?)row.B)
                .IsEqualTo(2);
            Console.WriteLine(row.A);
            Console.WriteLine(row.B);

        }
        #endregion

        #region No27
        [TestMethod]
        public void TestEnumeration()
        {
            var en = connection.Query<int>("select 1 as one union all select 2 as one", buffered: false);
            var i = en.GetEnumerator();
            i.MoveNext();

            bool gotException = false;
            try
            {
                var aa = new SqlConnection(ConfigurationManager.AppSettings["ConnectionString"]);

                var x = aa.Query<int>("select 1 as one", buffered: false).First();
            }
            catch (Exception)
            {
                gotException = true;
            }

            while (i.MoveNext())
            { }

            // should not exception, since enumerated
            var xx = connection.Query<int>("select 1 as one", buffered: false);
            Console.WriteLine(gotException);
        }
        #endregion

        #region No28
        public void TestNakedBigInt()
        {
            long foo = 12345;
            var result = connection.Query<long>("select @foo", new { foo }).Single();
            foo.IsEqualTo(result);
        }
        #endregion

        #region No29
        class WithBigInt
        {
            public long Value { get; set; }
        }

        class User
        {
            public int Id { get; set; }
            public string Name { get; set; }
        }
        class Post
        {
            public int Id { get; set; }
            public User Owner { get; set; }
            public string Content { get; set; }
            public Comment Comment { get; set; }
        }
        public void TestMultiMap()
        {
            var createSql = @"
                create table #Users (Id int, Name varchar(20))
                create table #Posts (Id int, OwnerId int, Content varchar(20))

                insert #Users values(99, 'Sam')
                insert #Users values(2, 'I am')

                insert #Posts values(1, 99, 'Sams Post1')
                insert #Posts values(2, 99, 'Sams Post2')
                insert #Posts values(3, null, 'no ones post')
";
            connection.Execute(createSql);
            try
            {
                var sql =
    @"select * from #Posts p 
left join #Users u on u.Id = p.OwnerId 
Order by p.Id";

                var data = connection.Query<Post, User, Post>(sql, (post, user) => { post.Owner = user; return post; }).ToList();
                var p = data.First();

                p.Content.IsEqualTo("Sams Post1");
                p.Id.IsEqualTo(1);
                p.Owner.Name.IsEqualTo("Sam");
                p.Owner.Id.IsEqualTo(99);

                data[2].Owner.IsNull();
            }
            finally
            {
                connection.Execute("drop table #Users drop table #Posts");
            }
        }
        #endregion

        #region No30
        //TODO 
        class ReviewBoard
        {
            public int Id { get; set; }
            public string Name { get; set; }
            public User User1 { get; set; }
            public User User2 { get; set; }
            public User User3 { get; set; }
            public User User4 { get; set; }
            public User User5 { get; set; }
            public User User6 { get; set; }
            public User User7 { get; set; }
            public User User8 { get; set; }
            public User User9 { get; set; }
        }
        [TestMethod]
        public void TestMultiMapArbitraryMaps()
        {
            // please excuse the trite example, but it is easier to follow than a more real-world one
            var createSql = @"
                create table ReviewBoards (Id int, Name varchar(20), User1Id int, User2Id int, User3Id int, User4Id int, User5Id int, User6Id int, User7Id int, User8Id int, User9Id int)
                create table Users (Id int, Name varchar(20))

                insert  Users values(1, 'User 1')
                insert  Users values(2, 'User 2')
                insert  Users values(3, 'User 3')
                insert  Users values(4, 'User 4')
                insert  Users values(5, 'User 5')
                insert  Users values(6, 'User 6')
                insert  Users values(7, 'User 7')
                insert  Users values(8, 'User 8')
                insert  Users values(9, 'User 9')

                insert ReviewBoards values(1, 'Review Board 1', 1, 2, 3, 4, 5, 6, 7, 8, 9)
";
            // connection.Execute(createSql);
            try
            {
                var sql = @"
                    select 
                        rb.Id, rb.Name,
                        u1.*, u2.*, u3.*, u4.*, u5.*, u6.*, u7.*, u8.*, u9.*
                    from  ReviewBoards rb
                        inner join  Users u1 on u1.Id = rb.User1Id
                        inner join  Users u2 on u2.Id = rb.User2Id
                        inner join  Users u3 on u3.Id = rb.User3Id
                        inner join  Users u4 on u4.Id = rb.User4Id
                        inner join  Users u5 on u5.Id = rb.User5Id
                        inner join  Users u6 on u6.Id = rb.User6Id
                        inner join  Users u7 on u7.Id = rb.User7Id
                        inner join  Users u8 on u8.Id = rb.User8Id
                        inner join  Users u9 on u9.Id = rb.User9Id
";

                var types = new[] { typeof(ReviewBoard), typeof(User), typeof(User), typeof(User), typeof(User), typeof(User), typeof(User), typeof(User), typeof(User), typeof(User) };

                Func<object[], ReviewBoard> mapper = (objects) =>
                {
                    var board = (ReviewBoard)objects[0];
                    board.User1 = (User)objects[1];
                    board.User2 = (User)objects[2];
                    board.User3 = (User)objects[3];
                    board.User4 = (User)objects[4];
                    board.User5 = (User)objects[5];
                    board.User6 = (User)objects[6];
                    board.User7 = (User)objects[7];
                    board.User8 = (User)objects[8];
                    board.User9 = (User)objects[9];
                    return board;
                };

                var data = connection.Query<ReviewBoard>(sql, types, mapper).ToList();

                var p = data.First();
                p.Id.IsEqualTo(1);
                p.Name.IsEqualTo("Review Board 1");
                p.User1.Id.IsEqualTo(1);
                p.User2.Id.IsEqualTo(2);
                p.User3.Id.IsEqualTo(3);
                p.User4.Id.IsEqualTo(4);
                p.User5.Id.IsEqualTo(5);
                p.User6.Id.IsEqualTo(6);
                p.User7.Id.IsEqualTo(7);
                p.User8.Id.IsEqualTo(8);
                p.User9.Id.IsEqualTo(9);
                p.User1.Name.IsEqualTo("User 1");
                p.User2.Name.IsEqualTo("User 2");
                p.User3.Name.IsEqualTo("User 3");
                p.User4.Name.IsEqualTo("User 4");
                p.User5.Name.IsEqualTo("User 5");
                p.User6.Name.IsEqualTo("User 6");
                p.User7.Name.IsEqualTo("User 7");
                p.User8.Name.IsEqualTo("User 8");
                p.User9.Name.IsEqualTo("User 9");
            }
            finally
            {
                // connection.Execute("drop table #Users drop table #ReviewBoards");
            }
        }

        #endregion

        #region No31
        //TODO
        [TestMethod]
        public void TestQueryMultipleBuffered()
        {
            using (var grid = connection.QueryMultiple("select 1; select 2; select @x; select 4", new { x = 3 }))
            {
                var a = grid.Read<int>();//buffered  默认是true
                var b = grid.Read<int>();
                var c = grid.Read<int>();
                var d = grid.Read<int>();

                a.Single().Equals(1);
                b.Single().Equals(2);
                c.Single().Equals(3);
                d.Single().Equals(4);
            }
        }

        [TestMethod]
        public void TestQueryMultipleNonBufferedIncorrectOrder()
        {
            using (var grid = connection.QueryMultiple("select 1; select 2; select @x; select 4", new { x = 3 }))
            {
                //TODO
                var a = grid.Read<int>(false);
                Console.WriteLine(a);
                try
                {
                    var b = grid.Read<int>(false);

                    Console.WriteLine(b);
                    //throw new InvalidOperationException(); // should have thrown
                }
                catch (InvalidOperationException)
                {
                    throw new InvalidOperationException();
                    // that's expected
                }

            }
        }

        [TestMethod]
        public void TestQueryMultipleNonBufferedCcorrectOrder()
        {
            using (var grid = connection.QueryMultiple("select 1; select 2; select @x; select 4", new { x = 3 }))
            {
                var a = grid.Read<int>(false).Single();
                var b = grid.Read<int>(false).Single();
                var c = grid.Read<int>(false).Single();
                var d = grid.Read<int>(false).Single();

                a.Equals(1);
                b.Equals(2);
                c.Equals(3);
                d.Equals(4);
            }
        }
        #endregion

        #region No32
        public void ExecuteReader()
        {
            var dt = new DataTable();
            dt.Load(connection.ExecuteReader("select 3 as [three], 4 as [four]"));
            dt.Columns.Count.IsEqualTo(2);
            dt.Columns[0].ColumnName.IsEqualTo("three");
            dt.Columns[1].ColumnName.IsEqualTo("four");
            dt.Rows.Count.IsEqualTo(1);
            ((int)dt.Rows[0][0]).IsEqualTo(3);
            ((int)dt.Rows[0][1]).IsEqualTo(4);
        }
        #endregion

        #region No33
        [TestMethod]
        public void TestMultiReaderBasic()
        {
            var sql = @"select 1 as Id      select 'abc' as name   select 1 as Id union all select 2 as Id";
            int i, j;
            string s;
            using (var multi = connection.QueryMultiple(sql))
            {
                i = multi.Read<int>().First();
                s = multi.Read<string>().Single();
                j = multi.Read<int>().Sum();
            }
            //SqlMapper.Assert.IsEqualTo(i, 1);
            Console.WriteLine("i:{0}", i);
            //SqlMapper.Assert.IsEqualTo(s, "abc");
            Console.WriteLine("s:{0}", s);
            //SqlMapper.Assert.IsEqualTo(j, 3);
            Console.WriteLine("j:{0}", j);
        }

        #endregion

        #region No34

        enum TestEnum : byte
        {
            Bla = 1
        }
        class TestEnumClass
        {
            public TestEnum? EnumEnum { get; set; }
        }
        class TestEnumClassNoNull
        {
            public TestEnum EnumEnum { get; set; }
        }
        //TODO
        [TestMethod]
        public void TestEnumWeirdness()
        {
            connection.Query<TestEnumClass>("select null as [EnumEnum]").First().EnumEnum.IsEqualTo(null);
            connection.Query<TestEnumClass>("select cast(1 as tinyint) as [EnumEnum]").First().EnumEnum.IsEqualTo(TestEnum.Bla);
        }
        [TestMethod]
        public void TestEnumStrings()
        {
            connection.Query<TestEnumClassNoNull>("select 'BLA' as [EnumEnum]").First().EnumEnum.IsEqualTo(TestEnum.Bla);
            connection.Query<TestEnumClassNoNull>("select 'bla' as [EnumEnum]").First().EnumEnum.IsEqualTo(TestEnum.Bla);

            connection.Query<TestEnumClass>("select 'BLA' as [EnumEnum]").First().EnumEnum.IsEqualTo(TestEnum.Bla);
            connection.Query<TestEnumClass>("select 'bla' as [EnumEnum]").First().EnumEnum.IsEqualTo(TestEnum.Bla);
        }
        #endregion

        #region No35

        class Person
        {
            public int PersonId { get; set; }
            public string Name { get; set; }
            public string Occupation { get; private set; }
            public int NumberOfLegs = 2;
            public Address Address { get; set; }
        }

        class Address
        {
            public int AddressId { get; set; }
            public string Name { get; set; }
            public int PersonId { get; set; }
        }

        class Extra
        {
            public int Id { get; set; }
            public string Name { get; set; }
        }
        //TODO
        [TestMethod]
        public void TestSupportForDynamicParametersOutputExpressions()
        {
            var bob = new Person { Name = "bob", PersonId = 1, Address = new Address { PersonId = 2 } };

            var p = new DynamicParameters(bob);
            p.Output(bob, b => b.PersonId);
            p.Output(bob, b => b.Occupation);
            p.Output(bob, b => b.Name);
            p.Output(bob, b => b.NumberOfLegs);
            p.Output(bob, b => b.Address.Name);
            p.Output(bob, b => b.Address.PersonId);

            connection.Execute(@"
SET @Occupation = 'grillmaster' 
SET @PersonId = @PersonId + 1 
SET @NumberOfLegs = @NumberOfLegs - 1
-- SET @AddressName = 'bobs burgers'
SET @AddressPersonId = @PersonId", p);

            Console.WriteLine("p:{0}", JsonConvert.SerializeObject(p));
            Console.WriteLine("bob:{0}", JsonConvert.SerializeObject(bob));

            //bob:{"NumberOfLegs":1,"PersonId":2,"Name":"bob","Occupation":"grillmaster","Address":{"AddressId":0,"Name":"bobs burgers","PersonId":2}}
            //bob:{"NumberOfLegs":1,"PersonId":2,"Name":"bob","Occupation":"grillmaster","Address":{"AddressId":0,"Name":"bobs burgers","PersonId":2}}
            //bob:{"NumberOfLegs":1,"PersonId":2,"Name":"bob","Occupation":"grillmaster","Address":{"AddressId":0,"Name":null,"PersonId":2}}

            //bob.Occupation.IsEqualTo("grillmaster");
            //bob.PersonId.IsEqualTo(2);
            //bob.NumberOfLegs.IsEqualTo(1);
            //bob.Address.Name.IsEqualTo("bobs burgers");
            //bob.Address.PersonId.IsEqualTo(2);
        }
        #endregion
    }
}
