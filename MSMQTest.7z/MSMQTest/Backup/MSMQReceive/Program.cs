﻿using System;
using System.Collections.Generic;
using System.Text;
using MSMQTest.Model;

namespace MSMQReceive
{
    class Program
    {
        static void Main(string[] args)
        {
            ThreadManager.Instance.Start();
            Console.WriteLine("quit为退出");
            string receiveKey = Console.ReadLine();
            while (receiveKey.ToLower() != "quit")
            {
                receiveKey = Console.ReadLine();
            }
            ThreadManager.Instance.Stop();
            Console.Read();
        }
    }
}
