﻿using System;
using System.Collections.Generic;
using System.Text;
using MSMQTest.Model;

namespace MSMQReceive
{
    /// <summary>
    /// 接收消息队列
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            ThreadManager.Instance.Start();
            Console.WriteLine("quit退出退出发布会");
            string receiveKey = Console.ReadLine();
            while (receiveKey.ToLower() != "quit")
            {
                receiveKey = Console.ReadLine();
            }
            ThreadManager.Instance.Stop();
            Console.Read();
        }
    }
}
