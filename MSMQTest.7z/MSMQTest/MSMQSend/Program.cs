﻿using System;
using System.Collections.Generic;
using System.Text;
using MSMQTest.Model;

namespace MSMQSend
{
    /// <summary>
    /// 发送消息队列
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            MSMQIndex mqIndex = new MSMQIndex();
            mqIndex.IndexName = "IndexName";
            List<int> list = new List<int>();

            Console.WriteLine("quit主动退出发布会现场,回车发送参加发布会");
            string receiveKey = Console.ReadLine();

            while (receiveKey.ToLower() != "quit")
            {
                try
                {
                    mqIndex.IndexName = "华为荣耀7发布会现在开始..........." + DateTime.Now.ToString();
                    
                    list.Clear();
                    int i = 0;
                    Random random = new Random();
                    while (i++ < 3)
                    {
                        list.Add(random.Next(i, 10000));
                    }
                    mqIndex.Item.Clear();
                    mqIndex.Item.Add(CommandType.Create, list);

                    MSMQManager.InstanceLocalComputer.Send(mqIndex);
                }
                catch(Exception ex)
                {
                    Console.WriteLine("发布会结束了 等下棋再来吧 亲");
                    //Console.WriteLine(ex.Message);
                    LogHelper.WriteLog(ex);
                }

                Console.WriteLine("quit主动退出发布会现场,回车发送参加发布会");
                receiveKey = Console.ReadLine();
            }

            MSMQManager.InstanceLocalComputer.Dispose();
        }
    }
}
