﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;

namespace MyWeb
{
    /// <summary>
    /// MyService 的摘要说明
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // 若要允许使用 ASP.NET AJAX 从脚本中调用此 Web 服务，请取消注释以下行。 
    // [System.Web.Script.Services.ScriptService]
    public class MyService : System.Web.Services.WebService
    {
        MyTestEntities db = new MyTestEntities();
        [WebMethod]
        public string HelloWorld()
        {
            return "Hello World";
        }

        /// <summary>
        /// 根据用户生日查询姓名
        /// </summary>
        /// <param name="brithday"></param>
        /// <returns></returns>
        [WebMethod(Description="请选择？")]
        public string WhoAreYou(string brithday)
        {
            List<WhoAreYou> list = new List<WhoAreYou>();
            WhoAreYou w=list[0];
            return w.Name;
        }
    }
}
