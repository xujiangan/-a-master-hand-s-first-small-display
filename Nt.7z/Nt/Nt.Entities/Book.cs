﻿
namespace Nt.Entities
{
    public class Book
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Author { get; set; }
        public string ISBN { get; set; }
        public int CategoryId { get; set; }
        public string ContentDescription { get; set; }
        public decimal UnitPrice { get; set; }
    }
}
