﻿using Nt.Entities;
using System.Collections.Generic;

namespace Nt.IRepository
{
   public interface IBookRepository
    {
      bool  AddBook(Book book);
       List<Book> GetBooksList();
    }
}
