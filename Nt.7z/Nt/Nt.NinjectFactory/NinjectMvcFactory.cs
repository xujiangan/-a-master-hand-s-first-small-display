﻿using Ninject;
using Nt.IRepository;
/*************************************************************************
*GUID：b048ff5c-1bee-4691-9cba-ac26264036c2 
*CLR：4.0.30319.18444
*Machine:  SHS
*Creater：Shihs
*Time：2014/10/14 10:24:44
*Code Caption:
***************************************************************************/
using Nt.SqlRepository;
using System;
using System.Web.Mvc;
using System.Web.Routing;

namespace Nt.NinjectFactory
{
    public class NinjectMvcFactory : DefaultControllerFactory,IDisposable
    {
        private readonly IKernel _kernel;

        public NinjectMvcFactory()
        {
            _kernel = new StandardKernel();
            AddBindings();
        }

        protected override IController GetControllerInstance(RequestContext requestContext, Type controllerType)
        {
            return controllerType == null ? null : (IController)_kernel.Get(controllerType);
        }

        private void AddBindings()
        {
            _kernel.Bind<IBookRepository>().To<BookRepository>();
        }

        public void Dispose()
        {
           _kernel.Dispose();
        }
    }
}
