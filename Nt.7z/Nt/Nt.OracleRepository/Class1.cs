﻿

/*************************************************************************
*GUID：d3afe6eb-e07c-41a1-ad83-d24f7bc0b4df 
*CLR：4.0.30319.18444
*Machine:  SHS
*Creater：Shihs
*Time：2014/10/14 16:38:39
*Code Caption:
***************************************************************************/

namespace Nt.OracleRepository
{
    class Class1
    {
    }
}
