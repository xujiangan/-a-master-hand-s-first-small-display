using System.Web;

namespace Nt.RepFactory
{
	/// <summary>
	/// ���������
	/// </summary>
	public class CacheHelper
	{
		/// <summary>
		/// ��ȡ��ǰӦ�ó���ָ��CacheKey��Cacheֵ
		/// </summary>
		/// <param name="cacheKey"></param>
		/// <returns></returns>
		public static object GetCache(string cacheKey)
		{
			System.Web.Caching.Cache objCache = HttpRuntime.Cache;
			return objCache[cacheKey];
		}

		/// <summary>
		/// ���õ�ǰӦ�ó���ָ��CacheKey��Cacheֵ
		/// </summary>
		/// <param name="cacheKey"></param>
		/// <param name="obj"></param>
		public static void SetCache(string cacheKey, object obj)
		{
			System.Web.Caching.Cache objCache = HttpRuntime.Cache;
			objCache.Insert(cacheKey, obj);
		}

        public static void RemoveCache(string cacheKey)
        {
            System.Web.Caching.Cache objCache = HttpRuntime.Cache;
            objCache.Remove(cacheKey);
        }
	}
}
