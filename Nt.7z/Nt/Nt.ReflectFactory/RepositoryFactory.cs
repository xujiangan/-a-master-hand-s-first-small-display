﻿using Nt.IRepository;
using Nt.RepFactory;
/*************************************************************************
*GUID：d60c53f5-ddfe-4998-b646-ddf4062e80c8 
*CLR：4.0.30319.18444
*Machine:  SHS
*Creater：Shihs
*Time：2014/10/14 14:53:10
*Code Caption:
***************************************************************************/
using System.Configuration;
using System.Reflection;

namespace Nt.ReflectFactory
{
    public class RepositoryFactory
    {
        private static readonly string AssemblyPath = ConfigurationManager.AppSettings["Dal"];

        #region CreateObject

        //不使用缓存
        private static object CreateObjectNoCache(string assemblyPath, string classNamespace)
        {
            try
            {
                object objType = Assembly.Load(assemblyPath).CreateInstance(classNamespace);
                return objType;
            }
            catch
            {
                //string str=ex.Message;// 记录错误日志
                return null;
            }
        }

        //使用缓存
        private static object CreateObject(string assemblyPath, string classNamespace)
        {
            object objType = CacheHelper.GetCache(classNamespace);

            if (objType == null)
            {
                Log.WriteLog("创建");
                try
                {
                    objType = Assembly.Load(assemblyPath).CreateInstance(classNamespace);
                    CacheHelper.SetCache(classNamespace, objType);// 写入缓存
                }
                catch
                {
                    //string str=ex.Message;// 记录错误日志
                }
            }
            else
            {
                Log.WriteLog("缓存");
            }
            return objType;
        }
        #endregion


        ///// <summary>
        ///// 得到一个对象实体，从缓存中
        ///// </summary>
        //public Books GetModelByCache(int id)
        //{
        //    string cacheKey = "BooksModel-" + id;
        //    object objModel = Maticsoft.Common.DataCache.GetCache(cacheKey);
        //    if (objModel == null)
        //    {
        //        try
        //        {
        //            objModel = _dal.GetModel(id);
        //            if (objModel != null)
        //            {
        //                int modelCache = ConfigHelper.GetConfigInt("ModelCache");
        //                Maticsoft.Common.DataCache.SetCache(cacheKey, objModel, DateTime.Now.AddMinutes(modelCache), TimeSpan.Zero);
        //            }
        //        }
        //        catch { }
        //    }
        //    return (Books)objModel;
        //}


        public static IBookRepository BookRepository()
        {
            string classNamespace = AssemblyPath + ".BookRepository";
            object objType = CreateObject(AssemblyPath, classNamespace);
            return (IBookRepository)objType;
        }


    }
}
