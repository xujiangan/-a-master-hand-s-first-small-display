﻿using Nt.Entities;
using Nt.IRepository;
using System.Linq;

namespace Nt.SqlRepository
{
   public class BookRepository : IBookRepository
    {
       readonly Db db = new Db();
        public bool AddBook(Book book)
        {
            db.Book.Add(book);
           var result= db.SaveChanges();
           return result > 0;
        }

        public System.Collections.Generic.List<Book> GetBooksList()
        {
            return db.Book.Select(x => x).ToList();
        }
    }
}
