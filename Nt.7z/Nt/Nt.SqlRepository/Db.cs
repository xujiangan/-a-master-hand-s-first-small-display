﻿using Nt.Entities;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;

namespace Nt.SqlRepository
{
    public class Db:DbContext
    {
        private const string ConnectionStr = "Data Source=.;Initial Catalog=Lucene1;Integrated Security=True";
        //private static readonly string ConnectionStr = System.Configuration.ConfigurationManager.ConnectionStrings["GosDB"].ConnectionString;
        public Db()
            : base(ConnectionStr) { }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            //base.OnModelCreating(modelBuilder);
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();
        }

        public DbSet<Book> Book { get; set; }
    }
}
