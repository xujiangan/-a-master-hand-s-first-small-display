﻿using Nt.Entities;
using Nt.IRepository;
using Nt.ReflectFactory;
using System.Web.Mvc;


namespace Nt.Web.Controllers
{
    public class BookController : Controller
    {
        private readonly IBookRepository _repository;

        /// <summary>
        /// 依赖注入
        /// </summary>
        /// <param name="rep"></param>
        public BookController(IBookRepository rep)
        {
            _repository = rep;
        }

        ///// <summary>
        ///// 反射机制
        ///// </summary>
        //public BookController()
        //{
        //    _repository = RepositoryFactory.BookRepository();
        //}


        public ActionResult Index()
        {
            var model = _repository.GetBooksList();
            return View(model);
        }

        //public JsonResult Index()
        //{
        //    var book = new Book { Id = 1, Title = "c#基础教程", Author = "Jim", CategoryId = 22, ISBN = "KNJ89009M1", ContentDescription = "C#是微软公司发布的一种面向对象的、运行于.NET Framework之上的高级程序设计语言。", UnitPrice = 88 };
        //    var result = _repository.AddBook(book);
        //    return Json(new { Result = result },JsonRequestBehavior.AllowGet);
        //}

        public JsonResult Create()
        {
            var book = new Book
            {
                Id = 1,
                Title = "c#基础教程",
                Author = "Jim",
                CategoryId = 22,
                ISBN = "KNJ89009M1",
                ContentDescription = "C#是微软公司发布的一种面向对象的、运行于.NET Framework之上的高级程序设计语言。",
                UnitPrice = 88
            };
            var result = _repository.AddBook(book);
            return Json(new {Result = result});
        }

        public ActionResult AddBook()
        {
            //var book = new Book { Id = 1, Title = "c#基础教程", Author = "Jim", CategoryId = 22, ISBN = "KNJ89009M1", ContentDescription = "C#是微软公司发布的一种面向对象的、运行于.NET Framework之上的高级程序设计语言。", UnitPrice = 88 };
            //var result = _repository.AddBook(book);
            return View();
        }
    }
}