﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ShoppingCart
{
    public partial class AddToCart : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            AddTo();
        }

        void AddTo()
        {
            Dictionary<string, CartInfo> storage = new Dictionary<string, CartInfo>();

            //读取Cookie
            CookieHelper cookie = new CookieHelper(storage);
            storage = cookie.GetUserCookie();

            //接收商品ID
            string PID = Request.QueryString["pid"];
            if (!string.IsNullOrWhiteSpace(PID))
            {
                //判断商品状态
                if (MockDB.product.Find(p => p.PID == PID) == null)
                {
                    Response.Write("<script>alert('该商品不存在！');</script>");
                    return;
                }
                else
                {
                    long ticks = DateTime.Now.Ticks;
                    if (storage.ContainsKey(PID)) //Cookie已有该商品
                    {
                        storage[PID].Nums += 1; //数量加1
                        storage[PID].Order = ticks; //更新Ticks到最新
                    }
                    else
                        storage.Add(PID, new CartInfo { Nums = 1, Order = ticks });

                    //存入Cookie
                    cookie.SetUserCookie();
                }
            }

            Response.Redirect("Cart.html");
        }
    }
}