﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ShoppingCart
{
    public class CartInfo
    {
        /// <summary>
        /// 商品数量
        /// </summary>
        public int Nums { get; set; }
        /// <summary>
        /// 商品的排序，越大越排在前面
        /// </summary>
        public long Order { get; set; }
    }
}