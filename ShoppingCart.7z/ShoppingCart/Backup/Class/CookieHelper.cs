﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;

namespace ShoppingCart
{
    public class CookieHelper
    {
        JavaScriptSerializer serializer = new JavaScriptSerializer();
        Dictionary<string, CartInfo> storage;

        public CookieHelper(Dictionary<string, CartInfo> storage)
        {
            this.storage = storage;
        }

        public Dictionary<string, CartInfo> GetUserCookie()
        {
            HttpCookie cookie = HttpContext.Current.Request.Cookies["ShoppingCart"];
            if (cookie != null && !string.IsNullOrWhiteSpace(cookie.Value))
            {
                storage = serializer.Deserialize<Dictionary<string, CartInfo>>(cookie.Value);
                if (storage == null)
                    return new Dictionary<string, CartInfo>();
            }
            return storage;
        }

        public void SetUserCookie()
        {
            HttpCookie cookie = new HttpCookie("ShoppingCart");
            //cookie.Domain = "yourDomain.com";
            cookie.Value = serializer.Serialize(storage);
            cookie.Expires = DateTime.Now.AddMonths(1);
            HttpContext.Current.Response.Cookies.Add(cookie);
        }
    }
}