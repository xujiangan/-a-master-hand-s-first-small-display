﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ShoppingCart
{
    /// <summary>
    /// 模拟商品数据
    /// </summary>
    public class MockDB
    {
        /// <summary>
        /// 在真实环境中，商品量大时，这里是整个购物车的性能瓶颈，
        /// 可以采用其他的数据结构来存储商品，如散列表会得到更快的检索速度（商品ID作为KEY）
        /// </summary>
        public readonly static List<Product> product = new List<Product>();
        static MockDB()
        {
            product = new List<Product> { 
                new Product{PID="111",PName="商品一", PPrice=1000.50, PIntegration=10, PPic="Images/111.png", PDesc="商品一描述"},
                new Product{PID="222",PName="商品二", PPrice=2000.00, PIntegration=20, PPic="Images/222.png", PDesc="商品二描述"},
                new Product{PID="333",PName="商品三", PPrice=3000.00, PIntegration=30, PPic="Images/333.png", PDesc="商品三描述"}
            };
        }
    }
}