﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ShoppingCart
{
    public class Product : IComparable<Product>
    {
        /// <summary>
        /// 商品ID
        /// </summary>
        public string PID { get; set; }
        /// <summary>
        /// 商品名称
        /// </summary>
        public string PName { get; set; }
        /// <summary>
        /// 商品价格
        /// </summary>
        public double PPrice { get; set; }
        /// <summary>
        /// 商品积分
        /// </summary>
        public int PIntegration { get; set; }
        /// <summary>
        /// 商品图片
        /// </summary>
        public string PPic { get; set; }
        /// <summary>
        /// 商品描述
        /// </summary>
        public string PDesc { get; set; }
        /// <summary>
        /// 商品数量
        /// </summary>
        public int PNums { get; set; }
        /// <summary>
        /// 商品在购物车上的排序
        /// </summary>
        public long PSort { get; set; }

        public int CompareTo(Product other)
        {
            return other.PSort.CompareTo(this.PSort);
        }
    }
}