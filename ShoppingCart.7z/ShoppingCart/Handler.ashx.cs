﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Threading;

namespace ShoppingCart
{
    /// <summary>
    /// Handler 的摘要说明
    /// </summary>
    public class Handler : IHttpHandler
    {
        JavaScriptSerializer serializer = new JavaScriptSerializer();
        Dictionary<string, CartInfo> storage = new Dictionary<string, CartInfo>();
        List<Product> list = new List<Product>();
        CookieHelper cookie;

        public string this[string name] { get { return HttpContext.Current.Request.QueryString[name]; } }

        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/plain";
            //Thread.Sleep(1000);
            //读取Cookie
            cookie = new CookieHelper(storage);
            storage = cookie.GetUserCookie();

            if (this["action"] == "edit")
                SetProductsNums(this["pid"], this["inc"]);
            else if (this["action"] == "clear")
                ClearCart();

            GetCartList();
        }

        /// <summary>
        /// 获取商品列表
        /// </summary>
        void GetCartList()
        {
            foreach (var item in storage)
            {
                Product current = MockDB.product.Find(p => p.PID == item.Key);
                list.Add(new Product { PID = item.Key, PNums = item.Value.Nums, PName = current.PName, PPrice = current.PPrice, PIntegration = current.PIntegration, PPic = current.PPic, PSort = item.Value.Order });
            }
            if (list.Count > 1)
                list.Sort();

            HttpContext.Current.Response.Write(serializer.Serialize(list));
        }

        /// <summary>
        /// 修改商品数量
        /// </summary>
        void SetProductsNums(string pid, string inc)
        {
            //判断商品状态
            if (MockDB.product.Find(p => p.PID == pid) != null)
            {
                if (storage.ContainsKey(pid))
                {
                    if (inc.StartsWith("use")) //修改操作
                        storage[pid].Nums = int.Parse(inc.TrimStart("use".ToArray()));
                    else //递增、减操作
                        storage[pid].Nums += int.Parse(inc);

                    if (storage[pid].Nums <= 0)
                        storage.Remove(pid);

                    //存入Cookie
                    cookie.SetUserCookie();
                }
            }
        }

        /// <summary>
        /// 清空购物车
        /// </summary>
        void ClearCart()
        {
            storage.Clear();

            //存入Cookie
            cookie.SetUserCookie();
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}