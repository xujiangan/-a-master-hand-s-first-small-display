﻿/*
* 实现功能：商品数量的编辑；商品信息合计；自动分页。
*/

var currentPage = 1; //当前页
var recordNums = 0; //总记录数
var pageSize = 10; //每页显示的记录数

$(function () {
    SendAjax();
})

function SendAjax(p) {
    //合计信息初始化
    var statistics = new Statistics();
    var begin = (currentPage - 1) * pageSize;  //起始记录
    var end = currentPage * pageSize;  //结束记录
    $("#cartLoading").show();

    $.ajax({
        url: "Handler.ashx?rand=" + Math.random(),
        dataType: "json",
        data: p,
        success: function (json) {
            recordNums = 0;
            //商品列表呈现模板
            var trBody = "<tr pid='{0}' init='{4}'><td style='width:50px'><img src='{5}' height='50' width='50' /></td><td style='text-align:left;vertical-align:top;'>{1}</td><td>￥{2}</td><td>{3}</td><td><a href='#' onclick='EditNums(this, -1);'>－</a> <input type='text' style='width:50%;text-align:center;' onchange='ProcessInput(this);' value='{4}' /> <a href='#' onclick='EditNums(this, 1);'>+</a></td><td><a href='#' onclick='EditNums(this, 0);'>删除</a></td></tr>";
            var data = "";
            if (json != null) {
                $.each(json, function (i, n) {
                    //获取总记录数
                    recordNums++;

                    //开始合计
                    statistics.Sum(n.PNums, n.PPrice * n.PNums, n.PIntegration * n.PNums);

                    //只显示当前商品列表页
                    if (i >= begin && i < end)
                        data += trBody.replace("{0}", n.PID).replace("{1}", n.PName).replace("{2}", n.PPrice.toFixed(2)).replace("{3}", n.PIntegration).replace("{4}", n.PNums).replace("{4}", n.PNums).replace("{5}", n.PPic);
                });
            }

            //最终呈现
            ProductsList(data, statistics);
        }
    });
}

function SetPage(mode) {
    if (mode == -1)
        currentPage--;
    else
        currentPage++;

    SendAjax();
}

function EditNums(obj, nums) {
    var pid = $(obj).parent().parent().attr('pid');
    var init = $(obj).parent().parent().attr('init');
    if (nums == 0 || (nums == -1 && init == 1)) {
        if (confirm("确定要删除该商品吗？"))
            SendAjax("action=edit&pid=" + pid + "&inc=use0");
        return;
    }
    SendAjax("action=edit&pid=" + pid + "&inc=" + nums);
}

function ProcessInput(obj) {
    val = $(obj).val();
    if (isNaN(val) || val <= 0 || val > 10000) {
        alert("请输入1~10000的数字！");
        $(obj).val($(obj).parent().parent().attr('init'));
        return;
    }
    SendAjax("action=edit&pid=" + $(obj).parent().parent().attr('pid') + "&inc=use" + val);
}

function ClearCart() {
    if (confirm("确定要删除所有商品吗？"))
        SendAjax("action=clear");
}

function ProductsList(data, statistics) {
    $("#cartLoading").hide();
    var trHead = "<thead><tr><td colspan='2'>商品</td><td style='width:10%'>价格</td><td style='width:10%'>积分</td><td style='width:10%'>数量</td><td style='width:10%'>操作</td></tr></thead>";
    if (data == "") {
        $("#cartWrap").html("<p>购物车中没有商品！</p>");
        $("#cartTotal").html("");
    }
    else {
        $("#cartWrap").html("<table cellpadding='5' cellspacing='1' border='0' width='100%' id='cartBody'>" + trHead + "<tbody>" + data + "</tbody></table>");
        $("#cartTotal").html("<p>" + Paging() + "<span style='float:left;'><a href='#' onclick='ClearCart();'>清空购物车</a></span><span>" + statistics.num + "件商品</span></p><p>价格总计：￥" + statistics.price.toFixed(2) + "</p><p>积分总计：" + statistics.integral + "</p>");
    }
}

function Paging() {
    var pageNums = 0, pageContainer = "";
    if (recordNums > pageSize) {
        pageContainer = "<span style='float:left;'>";
        pageNums = Math.ceil(recordNums / pageSize);
        if (currentPage <= 1) {
            pageContainer += currentPage + "/" + pageNums + " prev <a href='#' title='下一页' onclick='SetPage(1);'>next</a>";
        } else if (currentPage >= pageNums) {
            pageContainer += currentPage + "/" + pageNums + " <a href='#' title='上一页' onclick='SetPage(-1);'>prev</a> next";
        } else {
            pageContainer += currentPage + "/" + pageNums + " <a href='#' title='上一页' onclick='SetPage(-1);'>prev</a> <a href='#' title='下一页' onclick='SetPage(1);'>next</a>";
        }
        pageContainer += "&nbsp;&nbsp;&nbsp;</span>";
    }
    return pageContainer;
}

function Statistics() {
    this.num = 0; //商品数量总和
    this.price = 0; //商品价格总和
    this.integral = 0; //所得积分总和
}

Statistics.prototype.Sum = function (num, price, integral) {
    this.num += num;
    this.price += price;
    this.integral += integral;
}