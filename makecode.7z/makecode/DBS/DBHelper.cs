﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;


namespace DBS
{
    public class DBHelper
    {
        public DBHelper()
        {

        }

        private static string connectionstring = ConfigurationManager.AppSettings["ICGConString"].ToString();

        public int ExecuteNonQuery(string sql, SqlParameter[] sqlparemeter)
        {
            using (SqlConnection connection = new SqlConnection(connectionstring))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    try
                    {
                        PrepareCommand(cmd, connection, null, sql, sqlparemeter);
                        int rows = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                        return rows;
                    }
                    catch (System.Data.SqlClient.SqlException e)
                    {
                        throw e;
                    }
                    finally
                    {
                        cmd.Dispose();
                        connection.Close();
                    }
                }
            }
        }

        public object ExecuteScalar(string sql, SqlParameter[] sqlparemeter)
        {
            using (SqlConnection connection = new SqlConnection(connectionstring))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    try
                    {
                        PrepareCommand(cmd, connection, null, sql, sqlparemeter);
                        object obj = cmd.ExecuteScalar();
                        cmd.Parameters.Clear();
                        if ((Object.Equals(obj, null)) || (Object.Equals(obj, System.DBNull.Value)))
                        {
                            return null;
                        }
                        else
                        {
                            return obj;
                        }
                    }
                    catch (System.Data.SqlClient.SqlException e)
                    {
                        throw e;
                    }
                    finally
                    {
                        cmd.Dispose();
                        connection.Close();
                    }
                }
            }
        }

        public DataTable GetDataTable(string sql, SqlParameter[] sqlparemeter)
        {
            using (SqlConnection connection = new SqlConnection(connectionstring))
            {
                SqlCommand cmd = new SqlCommand();
                PrepareCommand(cmd, connection, null, sql, sqlparemeter);
                sql = null;
                using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                {
                    DataSet ds = new DataSet();
                    try
                    {
                        da.Fill(ds, "ds");
                        cmd.Parameters.Clear();
                    }
                    catch (System.Data.SqlClient.SqlException ex)
                    {
                        throw new Exception(ex.Message);
                    }
                    finally
                    {
                        cmd.Dispose();
                        connection.Close();
                    }
                    return ds.Tables[0];
                }
            }
        }

        public SqlDataReader ExecuteReader(string sql, SqlParameter[] sqlparemeter)
        {
            SqlConnection connection = new SqlConnection(connectionstring);
            SqlCommand cmd = new SqlCommand();
            try
            {
                PrepareCommand(cmd, connection, null, sql, sqlparemeter);
                SqlDataReader myReader = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                cmd.Parameters.Clear();
                return myReader;
            }
            catch (System.Data.SqlClient.SqlException e)
            {
                throw e;
            }
        }

        public string ExecuteSingleString(string sql, SqlParameter[] sqlparemeter)
        {
            object obj = ExecuteScalar(sql, sqlparemeter);
            if (obj == null)
                return "";//不存在
            else
                return obj.ToString();
        }


        public int Exists(string sql, SqlParameter[] sqlparemeter)
        {
            using (SqlDataReader da = ExecuteReader(sql, sqlparemeter))
            {
                if (da.HasRows)
                {
                    da.Close();
                    return 1;
                }
                da.Close();
            }
            return 0;
        }

        public int ExecuteNonQuerySqlList(List<string> sqllist)
        {
            using (SqlConnection connection = new SqlConnection(connectionstring))
            {
                connection.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = connection;
                SqlTransaction tx = connection.BeginTransaction();
                cmd.Transaction = tx;
                try
                {
                    for (int n = 0; n < sqllist.Count; n++)
                    {
                        string strsql = sqllist[n];
                        if (strsql.Trim().Length > 1)
                        {
                            cmd.CommandText = strsql;
                            cmd.ExecuteNonQuery();
                        }
                    }
                    tx.Commit();
                    return 1;
                }
                catch
                {
                    tx.Rollback();
                    return 0;
                }
                finally
                {
                    cmd.Dispose();
                    connection.Close();
                }
            }
        }

        private static void PrepareCommand(SqlCommand cmd, SqlConnection conn, SqlTransaction trans, string cmdText, SqlParameter[] cmdParms)
        {
            if (conn.State != ConnectionState.Open)
                conn.Open();
            cmd.Connection = conn;
            cmd.CommandText = cmdText;
            if (trans != null)
                cmd.Transaction = trans;
            cmd.CommandType = CommandType.Text;//cmdType;
            if (cmdParms != null)
            {
                foreach (SqlParameter parameter in cmdParms)
                {
                    if ((parameter.Direction == ParameterDirection.InputOutput || parameter.Direction == ParameterDirection.Input) &&
                        (parameter.Value == null))
                    {
                        parameter.Value = DBNull.Value;
                    }
                    cmd.Parameters.Add(parameter);
                }
            }
        }

        //public string GetloginnameByucode(string ucode)
        //{
        //    string sql = string.Format("select name from UsersTable where usercode=@usercode");
        //    SqlParameter[] para = new SqlParameter[] { new SqlParameter("@usercode", ucode) };
        //    return ExecuteSingleString(sql, para);
        //}

        //public string GetloginUcodeByUname(string uname)
        //{
        //    string sql = string.Format("select usercode from UsersTable where name=@name");
        //    SqlParameter[] para = new SqlParameter[] { new SqlParameter("@name", uname) };
        //    return ExecuteSingleString(sql, para);
        //}

        //public string GetUsercodeByNoteID(string noteid)
        //{
        //    string sql = string.Format("select usercode from usersnote where id=@id");
        //    SqlParameter[] para = new SqlParameter[] { new SqlParameter("@id", noteid) };
        //    return ExecuteSingleString(sql, para);
        //}

        ///// <summary>
        ///// 登陸事件 pass為加密之後的值
        ///// </summary>
        ///// <param name="name">帳號</param>
        ///// <param name="pass">密碼</param>
        ///// <returns>usercode</returns>
        //public string Login(string name, string pass)
        //{
        //    if (name == "" || pass == "")
        //    {

        //        return "";
        //    }
        //    else
        //    {
        //        string sql = string.Format("select usercode from Userstable where name=@name and pass=@pass");
        //        SqlParameter[] para = new SqlParameter[]
        //            {
        //                new SqlParameter("@name",name),
        //                new SqlParameter("@pass",pass)
        //            };
        //        return ExecuteSingleString(sql, para);
        //    }
        //}

        //public string Getnewscount(string usercode)
        //{
        //    string sql = string.Format("select count(id) from usersnews where usercode=@usercode");
        //    SqlParameter[] para = new SqlParameter[] { new SqlParameter("@usercode", usercode) };
        //    return ExecuteSingleString(sql, para);
        //}

        ////添加删除日志时调用此方法
        //public void UpdateCountsToNoto(string usercode, string noteid, int isdeletenow)
        //{
        //    string sql = "";
        //    if (isdeletenow == 1)//删除
        //    {
        //        sql = string.Format("select time from usersnote where id='{0}'", noteid);
        //        DateTime yearandmonth = Convert.ToDateTime(ExecuteSingleString(sql, null));
        //        sql = string.Format("update CountsToNotoSave set [notecount]=[notecount]-1 where usercode='{0}' and noteyear={1} and notemonth={2}", usercode, yearandmonth.Year, yearandmonth.Month);
        //        ExecuteNonQuery(sql, null);
        //    }
        //    else//新增
        //    {
        //        string sqlyearmonth = string.Format("select usercode  from CountsToNotoSave where usercode='{0}' and noteyear={1} and notemonth={2}", usercode, DateTime.Now.Year, DateTime.Now.Month);
        //        if (ExecuteSingleString(sqlyearmonth, null) != "")//新写日志 不是本月第一篇
        //        {
        //            sql = string.Format("update CountsToNotoSave set [notecount]=[notecount]+1 where usercode='{0}' and noteyear={1} and notemonth={2}", usercode, DateTime.Now.Year, DateTime.Now.Month);
        //            ExecuteNonQuery(sql, null);
        //        }
        //        else//本月第一篇
        //        {
        //            sql = string.Format("insert into CountsToNotoSave([usercode],[noteyear],[notemonth],[notecount]) values ('{0}',{1},{2},{3})", usercode, DateTime.Now.Year, DateTime.Now.Month, 1);
        //            ExecuteNonQuery(sql, null);
        //        }
        //    }
        //    sql = null;
        //}

        ////设置缓存前20条数据
        //public DataTable GetSetCasheForpublicpagesizedatatable()
        //{
        //    DataTable dt;
        //    string sql = string.Format("select top {1} id,time,title,viewcount,week ,byname,ordertime,weather,coordinates from  UsersNote where mypublic={0} order by ordertime desc", 1, PageSize);
        //    dt = GetDataTable(sql, null);
        //    DataHelper.SetCache("publicpagesizedatatable", dt);
        //    return dt;
        //}
    }

}