$(function () {

    //���ظ���
    $("a[name='labsh']").click(function () {
        var path = $(this).attr("path");
        alert(path);
    });

    $("span[name='fileup']").click(function () {
        // �ļ��ϴ� ------------------------- begin ---------------------------
        var button = $(this), interval;
        new AjaxUpload(button, {
            action: 'ajax/uploadimg.ashx',
            name: 'imgFile',
            onSubmit: function (file, ext) {
                //this.disable();
                interval = window.setInterval(function () {
                    var text = button.text();
                }, 200);
            },
            onComplete: function (file, response) {
                window.clearInterval(interval);
                this.enable();
                response = response.replace(/<pre>/ig, "").replace(/<\/pre>/ig, ""); //����
                var obj = $.parseJSON(response);

                if (obj[0].filetruename == "error") {
                    alert("�������ϴ����ļ�����!");
                    return false;
                }
                else if (obj[0].filetruename == "over") {
                    alert("�ļ�̫�����ϴ�������" + obj[0].filesize + "M���ļ�!");
                    return false;
                }

                var myid = $(button).attr("myid");

                $("#" + myid).html(obj[0].filetruename); //name
                $("#" + myid).attr("path", obj[0].filepath); //path

                $("#" + myid).parent().children().show(); //��ʾȫ��
            }
        });
    });

    $("a[name='adelete']").click(function () {
        var myid = $(this).attr("adeleteid");
        alert(myid);
        $("#" + myid).html(""); //name
        $("#" + myid).attr("path", ""); //path
        $("#" + myid).parent().children("a").hide();
    });

    //�ϴ���ť���¼�
    function init() {
        var objs = $("span[name='fileup']");
        $(objs).each(function () {
            $(this).click();
        });
    }

    init();
});