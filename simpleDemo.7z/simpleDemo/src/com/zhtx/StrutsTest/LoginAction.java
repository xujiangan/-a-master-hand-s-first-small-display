package com.zhtx.StrutsTest;

import com.opensymphony.xwork2.Action;

public class LoginAction implements Action  {

	@Override
	public String execute() throws Exception {
		if(username.equals("admin")&&password.equals("123")){
			return "success";
		}else{
			return "fail";
		}
	}
	
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	private String username;
	private String password;
	
	
}
