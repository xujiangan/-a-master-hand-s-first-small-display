package com.zhtx.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class JDBCTest {
	public static void main(String[] args) {
		String sql="select * from t_user";
		Connection conn = null;
		Statement st = null;
		ResultSet rs=null;
		
		try {
			//1 加载驱动
			Class.forName("com.mysql.jdbc.Driver");
			//2 创建连接字符串
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root", "y504549488");
			//3 创建sql语句执行对象
			st=conn.createStatement();
			//4 执行sql 
			rs=st.executeQuery(sql);
			while (rs.next()) {
				System.out.print(rs.getInt("UserId")+"  ");
				System.out.print(rs.getString("Name")+" ");
				System.out.print(rs.getInt("Age") +" ");
				System.out.println();
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			//5 关闭连接
			try {
				rs.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
			try {
				st.close();
			} catch (Exception e3) {
				e3.printStackTrace();
			}
			try {
				conn.close();
			} catch (Exception e4) {
				e4.printStackTrace();
			}
		}
	}
}
