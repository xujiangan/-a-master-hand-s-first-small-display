package com.zhtx.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;


public class TransactionTest {
	
	public static void main(String[] args) {
		Connection conn = null;
		try {
			conn=GetConnection();
			conn.setAutoCommit(false); 
//			AddUser(conn);
//			AddAccount(conn);
//			conn.commit();
			
		boolean flag=UpdateAccount(conn);  //执行成功了  返回false?
		conn.commit();
		System.out.println(flag);
			
		} catch (Exception e) {
			System.out.println("=========SQL EXception===========");
			e.printStackTrace();
			try {
				conn.rollback();
				System.out.println("事物回滚成功");
			} catch (Exception e2) {
				System.out.println("事物回滚异常"+e2.getMessage());
			}
		}finally {
			try {
				if(conn!=null)
					conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}
	
	//获取连接字符串对象
	public static Connection GetConnection(){
		Connection conn=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root", "y504549488");
		} catch (Exception e) {
			System.out.println("数据库连接失败"+e.getMessage());
		}
		return conn;
	}
	
	public static void AddUser(Connection conn) throws SQLException{
		String sql=" INSERT INTO t_user (UserId,NAME,Age) VALUES (1,'baiyan',15)";
		Statement st =conn.createStatement();
		int count=st.executeUpdate(sql);
		System.out.println("用户表插入"+count+"条数据");
		
	}
	
	public  static void AddAccount(Connection conn) throws SQLException{
		String sql="INSERT INTO t_account(UserId,Balance) VALUES (2,77)";
		Statement st = conn.createStatement();
		int count =st.executeUpdate(sql);
		System.out.println("向账户表插入"+count+"条数据");
	}
	
	public static boolean UpdateAccount(Connection conn)throws SQLException{
		String sql="update t_account set Balance=? where AccountId=? ";
		PreparedStatement ps = conn.prepareCall(sql);
		ps.setInt(1, 321);
		ps.setInt(2, 1);
		boolean flag= ps.execute(); 
		return flag;  
	}
	
}
