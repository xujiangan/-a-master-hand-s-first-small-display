package com.zhtx.springTest;

public class HelloChina implements IHelloMessage {

	@Override
	public String SayHello() {
		return "你好";
	}

}
