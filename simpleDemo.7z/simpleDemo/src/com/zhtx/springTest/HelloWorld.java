package com.zhtx.springTest;

public class HelloWorld implements IHelloMessage{

	@Override
	public String SayHello() {
		return "hello";
	}

}
