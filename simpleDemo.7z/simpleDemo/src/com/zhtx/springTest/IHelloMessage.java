package com.zhtx.springTest;

public interface IHelloMessage {
	public String SayHello();

}
