package com.zhtx.springTest;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;

public class Main {

	public static void main(String[] args) {
		//1 读取配置文件呢
		Resource r = new FileSystemResource("src/hello.xml");
		//2 加载配置文件 到ioc容器
		BeanFactory f = new XmlBeanFactory(r);
		//3 从容器中获取类实例
		Person person = (Person) f.getBean("person");
		
		System.out.println(person.SayHello());
	
	}

}
