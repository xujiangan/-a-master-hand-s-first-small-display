package com.zhtx.springTest;

public class Person {
	private IHelloMessage helloMessage;
	
	public String SayHello(){
	 return	helloMessage.SayHello();
	}

	public IHelloMessage getHelloMessage() {
		return helloMessage;
	}

	public void setHelloMessage(IHelloMessage helloMessage) {
		this.helloMessage = helloMessage;
	}
}
