package com.zhtx.test;

import java.sql.Connection;

import com.zhtx.utility.ConnectionFactory;

public class ConnectionFactoryTest {
	
	public static void main(String[] args) throws Exception{
		ConnectionFactory factory = ConnectionFactory.GetInstance();
		Connection conn = factory.GetConnection();
		System.out.println(conn.getAutoCommit());
	}
}
