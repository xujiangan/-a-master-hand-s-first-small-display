package com.zhtx.utility;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;


public class ConnectionFactory {
	private static String driver;
	private static String dburl;
	private static String user;
	private static String password;
	public static final ConnectionFactory factory = new ConnectionFactory();
	private Connection conn=null;
	//静态代码块  完成类属性初始化 
	static{
		Properties prop = new Properties();
		try {
			InputStream stream = ConnectionFactory.class.getClassLoader().getResourceAsStream("dbconfig.properties");
			prop.load(stream);
		} catch (Exception e) {
		   System.out.println("读取dbconfig.properties文件出错");
		}
		driver=prop.getProperty("driver");
		dburl=prop.getProperty("dburl");
		user=prop.getProperty("user");
		password=prop.getProperty("password");
	}
	
	public ConnectionFactory(){}
	public static ConnectionFactory GetInstance(){
		return factory;
	}
	
	public Connection GetConnection(){
		try {
			Class.forName(driver);
			conn=DriverManager.getConnection(dburl, user, password);
		} catch (Exception e) {
			System.out.println("创建连接对象异常");
			e.printStackTrace();
		}
		return conn;
	}
	
}
