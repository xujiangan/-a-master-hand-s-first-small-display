package com.zhtx.controller;

import java.io.IOException;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.zhtx.entity.PageParam;
import com.zhtx.entity.User;
import com.zhtx.service.UserService;



@Controller
public class UserController {
	@Resource
	UserService userService;
	
	/*
	 * 用户列表
	 * xugy 2015年12月20日
	 */
	@RequestMapping(value="user/index")
	public String Index(HttpServletRequest request){
		int page=1;
		try {
			page = Integer.parseInt(request.getParameter("page"));
		} catch (Exception e) {
		}
		int rowCount = userService.QueryUserCount();  //总记录数
		PageParam<User> pageParam = new PageParam<User>();
		pageParam.setPageSize(5); //每页显示数
		pageParam.setRowCount(rowCount);
		if(pageParam.getTotalPage()<page){
			page=pageParam.getTotalPage();
		}
		pageParam.setCurrPage(page);
		
		pageParam=userService.QueryUserList(pageParam);
		request.setAttribute("pageParam", pageParam);
		return "user/index";
	}
	
	/*
	 * 新增用户 
	 * xugy 2015年12月20日
	 */
	@RequestMapping(value="user/add")
	public String AddUser(){
		return "user/addUser";
	}
	
	@RequestMapping(value="user/processAddUser",method=RequestMethod.POST)
	public String processAddUser(HttpServletRequest request,User user){
		int num=userService.InsertUser(user);
		return Index(request);
	}
	
	
	/*
	 * 修改
	 */
	@RequestMapping(value="user/edit")
	public String EditUser(HttpServletRequest request,int userId){
		User user = userService.QueryUserById(userId);
		request.setAttribute("model", user);
		return "user/editUser";
	}
	
	@RequestMapping(value="user/processEditUser",method=RequestMethod.POST)
	public void ProcessEditUser(User user,javax.servlet.http.HttpServletResponse response){
		int num=userService.UpdateUserById(user);
		try {
			response.getWriter().write("success");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	@RequestMapping(value="user/processDeleteUser")
	public void ProcessDeleteUser(int userId,javax.servlet.http.HttpServletResponse response){
		int num=userService.DeleteUserById(userId);
		try {
			response.getWriter().write("success");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	
}
