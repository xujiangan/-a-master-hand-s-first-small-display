package com.zhtx.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.zhtx.entity.User;

@Repository
public interface IUserDal {

	int QueryUserCount();

	List<User> QueryUserList(Map<String, Object> params);

	int InsertUser(User user);

	User QueryUserById(int userId);

	int UpdateUserById(User user);

	int DeleteUserById(int userId);  

  
}
