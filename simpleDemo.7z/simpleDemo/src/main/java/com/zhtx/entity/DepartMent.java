package com.zhtx.entity;

public class DepartMent {
	private int departMentId;
	private int userId;
	private String describe;
	
	public DepartMent(){
		super();
	}
	
	public DepartMent(int departMentId,int userId,String describe){
		super();
		this.departMentId=departMentId;
		this.userId=userId;
		this.describe=describe;
	}
	
	
	public int getDepartMentId() {
		return departMentId;
	}
	public void setDepartMentId(int departMentId) {
		this.departMentId = departMentId;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getDescribe() {
		return describe;
	}
	public void setDescribe(String describe) {
		this.describe = describe;
	}

}
	