package com.zhtx.entity;

import java.util.List;

public class PageParam<T> {
	private int currPage = 1 ; // 当前页
	private int totalPage ; // 总页
	private int rowCount ; // 总记录数
	private int pageSize = 10; // 页大小
	private int offset; //偏移量
	private List<T> data ; // 数据
	
	//构造函数
	public PageParam(){
	}
	public PageParam(int pIndex,int pSize,int totalCount){
		
		currPage=pIndex;
		pageSize=pSize;
		rowCount=totalCount;
	}
	

	public int getCurrPage() {
		if(getTotalPage()<currPage){
			currPage=getTotalPage();
		}
		return currPage;
	}

	public void setCurrPage(int currPage) {
		this.currPage = currPage;
	}

	public int getTotalPage() {
		return totalPage;
	}

	public void setTotalPage(int totalPage) {
		this.totalPage = totalPage;
	}

	public int getRowCount() {
		return rowCount;
	}

	public void setRowCount(int rowCount) {
		int totalPage = rowCount / pageSize;
		if (rowCount % pageSize > 0) {
			totalPage += 1;
		}
		setTotalPage(totalPage);
		this.rowCount = rowCount;
	}

	public int getOffset() {
		offset=(currPage-1)*pageSize;
		return offset;
	}

	public void setOffset(int offset) {
		this.offset = offset;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public List<T> getData() {
		return data;
	}

	public void setData(List<T> data) {
		this.data = data;
	}
}
