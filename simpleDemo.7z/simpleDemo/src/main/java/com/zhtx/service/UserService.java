package com.zhtx.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.zhtx.dao.IUserDal;
import com.zhtx.entity.PageParam;
import com.zhtx.entity.User;

@Service
public class UserService {
	@Resource
	IUserDal userDal;
	/*
	 * 用户总记录数
	 */
	public int QueryUserCount() {
		return userDal.QueryUserCount();
	}
	/*
	 * 用户信息列表
	 */
	public PageParam<User> QueryUserList(PageParam<User> pageParam) {
		Map<String, Object> params = new HashMap<String,Object>();
		params.put("offset", pageParam.getOffset());
		params.put("size", pageParam.getPageSize());
		List<User> list = userDal.QueryUserList(params); 
		pageParam.setData(list);
		return pageParam;
	}
	public int InsertUser(User user) {
		return userDal.InsertUser(user);
	}
	public User QueryUserById(int userId) {
		return userDal.QueryUserById(userId);
	}
	public int UpdateUserById(User user) {
		return userDal.UpdateUserById(user);
	}
	public int DeleteUserById(int userId) {
		return userDal.DeleteUserById(userId);
	}
	
}
