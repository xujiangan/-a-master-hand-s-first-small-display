﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Activities;

namespace WFStartMachine
{

    public sealed class BiaoXiaoApprove : CodeActivity
    {
        // 定义一个字符串类型的活动输入参数
        public InArgument<string> Reason { get; set; }
        public InArgument<int> Money { get; set; }
        public OutArgument<bool> Approve { get; set; }

        // 如果活动返回值，则从 CodeActivity<TResult>
        // 派生并从 Execute 方法返回该值。
        protected override void Execute(CodeActivityContext context)
        {
            string reason = context.GetValue(Reason);
            int money = context.GetValue(Money);
            Console.WriteLine("报销金额，{0}，报销金额{1}",money,reason);

            Console.WriteLine("输入审批意见（y/n）");
            string isAgreen = Console.ReadLine();
            if (isAgreen.Equals("y", StringComparison.CurrentCultureIgnoreCase))
            {
                context.SetValue(Approve, true);
            }
            else {
                context.SetValue(Approve,false);
            }
        }
    }
}
