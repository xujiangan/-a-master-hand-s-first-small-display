﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LessOne
{
    class Program
    {
        static void Main(string[] args)
        {
            int? a=null;
            dynamic str = "10";//动态类型
            //Console.WriteLine(a);//可空类型
            p per = new p();
            Console.WriteLine(a ?? 0);//先判断是否为null 如果为null就给默认值
            Console.WriteLine(per.StrState);
            Console.ReadKey();
        }
        public class p
        {
            public int State { get; set; }
            public string StrState
            {
                get
                {
                    switch (State)
                    {
                        case 0:
                            return "上午";
                        case 1:
                            return "下午";
                        default:
                            return "";
                    }
                }
            }
    }
}
