using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Shortcut
{
    public partial class MainForm : Form
    {

        public MainForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Shortcut.CreateShortcut(Shortcut.GetDeskDir() + "\\��ѧVC��¼���.lnk", @"http://blog.csdn.net/testcs_dn", Shortcut.GetDeskDir(), "��ѧVC��¼���", AppDomain.CurrentDomain.BaseDirectory + "favicon.ico");
            MessageBox.Show("�����ɹ���");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (Shortcut.AddFavorites("http://blog.csdn.net/testcs_dn", "��ѧVC��¼���", null, AppDomain.CurrentDomain.BaseDirectory + "favicon.ico"))
            {
                MessageBox.Show("���ӳɹ���");

            }
            else
            {
                MessageBox.Show("����ʧ��");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (Shortcut.CreateProgramsShortcut("http://blog.csdn.net/testcs_dn", "��ѧVC��¼���", "��ѧVC��¼���", AppDomain.CurrentDomain.BaseDirectory + "favicon.ico"))
            {
                MessageBox.Show("���ӳɹ���");

            }
            else
            {
                MessageBox.Show("����ʧ��");
            }
        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        }
    }
}